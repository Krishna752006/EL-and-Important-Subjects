Create a multithreaded Java application that reads weather data from multiple input files and stores the records in a MySQL database. The program should use a database connection across all threads and ensure thread-safe database operations.

The input files (london.txt, paris.txt, newyork.txt) contain weather data in the following format:
CityName|Temperature|Humidity|Condition

Input Files:
london.txt:
London|15.2|80|Cloudy
London|12.5|90|Rainy

paris.txt:
Paris|20.5|60|Sunny
Paris|22.0|55|Clear

newyork.txt:
New York|10.0|70|Snowy
New York|8.5|85|Windy

Implement a Java class SharedConnectionMultithreading that initializes the database connection and creates a thread for each file.
Each thread should use the FileProcessor class (implementing Runnable) to process the assigned file line by line.
Validate the file records to ensure they match the expected format.
Log invalid records with error messages.
Use a synchronized method to handle database operations and ensure thread-safe writes.
Create the required MySQL table with the following structure:

CREATE DATABASE weatherdb;
USE weatherdb;
CREATE TABLE WeatherData (
    CityName VARCHAR(50),
    Temperature FLOAT,
    Humidity INT,
    Condition VARCHAR(100)
);
Ensure the program handles exceptions and logs errors for any issues encountered (e.g., file reading errors, database errors).
After execution, confirm that all valid records from the input files are successfully inserted into the database
SharedConnectionMultithreading.java
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class SharedConnectionMultithreading {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/weatherdb";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "yourpassword";
    
    public static void main(String[] args) {
        Connection connection = null;

        try {
            // Establish a database connection
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

            // Create threads for each input file
            Thread londonThread = new Thread(new FileProcessor("london.txt", connection));
            Thread parisThread = new Thread(new FileProcessor("paris.txt", connection));
            Thread newYorkThread = new Thread(new FileProcessor("newyork.txt", connection));

            // Start threads
            londonThread.start();
            parisThread.start();
            newYorkThread.start();

            // Wait for all threads to finish
            londonThread.join();
            parisThread.join();
            newYorkThread.join();

        } catch (SQLException | InterruptedException e) {
            e.printStackTrace();
        } finally {
            // Close the connection
            try {
                if (connection != null && !connection.isClosed()) {
                    connection.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
FileProcessor.java
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class FileProcessor implements Runnable {
    private String fileName;
    private Connection connection;

    public FileProcessor(String fileName, Connection connection) {
        this.fileName = fileName;
        this.connection = connection;
    }

    @Override
    public void run() {
        try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = br.readLine()) != null) {
                processLine(line);
            }
        } catch (IOException e) {
            System.err.println("Error reading file: " + fileName);
            e.printStackTrace();
        }
    }

    private synchronized void processLine(String line) {
        // Split the line manually, ensuring we can check the data without pattern matching
        String[] parts = line.split("\\|");

        if (parts.length == 4) {
            String cityName = parts[0];
            try {
                float temperature = Float.parseFloat(parts[1]);
                int humidity = Integer.parseInt(parts[2]);
                String condition = parts[3];

                // Validate the data (example: check temperature and humidity ranges)
                if (validateData(cityName, temperature, humidity, condition)) {
                    insertIntoDatabase(cityName, temperature, humidity, condition);
                } else {
                    System.err.println("Invalid data: " + line);
                }
            } catch (NumberFormatException e) {
                System.err.println("Invalid number format: " + line);
            }
        } else {
            System.err.println("Invalid record format: " + line);
        }
    }

    private boolean validateData(String cityName, float temperature, int humidity, String condition) {
        // Simple validation checks, e.g., temperature range and humidity bounds
        return temperature >= -50 && temperature <= 50 && humidity >= 0 && humidity <= 100;
    }

    private void insertIntoDatabase(String cityName, float temperature, int humidity, String condition) {
        // SQL to insert the weather data into the database
        String insertSQL = "INSERT INTO WeatherData (CityName, Temperature, Humidity, Condition) VALUES (?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(insertSQL)) {
            stmt.setString(1, cityName);
            stmt.setFloat(2, temperature);
            stmt.setInt(3, humidity);
            stmt.setString(4, condition);
            stmt.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Error inserting data into database: " + cityName);
            e.printStackTrace();
        }
    }
}
MySQL Setup
CREATE DATABASE weatherdb;
USE weatherdb;

CREATE TABLE WeatherData (
    CityName VARCHAR(50),
    Temperature FLOAT,
    Humidity INT,
    Condition VARCHAR(100)
);
Input:
File paris.txtHere are 6 test cases that will help validate the code:

Test Case 1: Valid Record
Input:
File london.txt


London|15.2|80|Cloudy
London|12.5|90|Rainy
Expected Outcome:
Both records are valid and should be inserted into the WeatherData table in MySQL.
The records will look like this in the database:
CityName	Temperature	Humidity	Condition
London	15.2	80	Cloudy
London	12.5	90	Rainy
-----------------------------------------------------------------------------------

Test Case 2: Invalid Temperature (Below Valid Range)



Paris|-60.0|60|Sunny
Expected Outcome:
The temperature -60.0 is outside the valid range (-50 to 50), so this record is invalid.
The record should not be inserted into the database.
The system should log the following error message:
kotlin

Invalid data: Paris|-60.0|60|Sunny
-----------------------------------------------------------------------------------
Test Case 3: Invalid Temperature (Above Valid Range)
Input:
File newyork.txt
New York|55.0|70|Snowy
Expected Outcome:
Invalid data: New York|55.0|70|Snowy
--------------------------------------------------------------------------------------

Test Case 4: Invalid Humidity
Input:
File london.txt
London|20.0|-10|Clear
Expected Outcome:
Invalid data: London|20.0|-10|Clear
-------------------------------------------------------------------------------------
Test Case 5: Invalid Record Format
Input:
File paris.txt
Paris|22.0|55
Paris|abc|60|Sunny
Expected Outcome:Invalid record format: Paris|22.0|55
Invalid number format: Paris|abc|60|Sunny
--------------------------------------------------------------------------------------------
Test Case 6: Valid Record with Edge Values
Input:
File newyork.txt
New York|0.0|100|Windy
New York|-50.0|0|Clear
Expected Outcome:
CityName	Temperature	Humidity	Condition
New York	  0.0	       100	     Windy
New York	-50.0	        0	     Clear
-------------------------------------------------------------------------------------------
To properly test the functionality of the code above, you can create a set of test cases to ensure that the system behaves as expected. These test cases will cover scenarios such as valid data, invalid data, edge cases for temperature and humidity, and general error handling.

Here are 6 test cases that will help validate the code:
