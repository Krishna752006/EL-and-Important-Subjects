public class a {
    public static void main(String[] args) {

        Multipliy1 m1 = new Multipliy1();
        Thread t1 = new Thread(m1);
        t1.start();

        Multipliy2 m2 = new Multipliy2();
        Thread t2 = new Thread(m2);
        t2.start();

        Multipliy3 m3 = new Multipliy3();
        Thread t3 = new Thread(m3);
        t3.start();

        Multipliy4 m4 = new Multipliy4();
        Thread t4 = new Thread(m4);
        t4.start();

        Multipliy5 m5 = new Multipliy5();
        Thread t5 = new Thread(m5);
        t5.start();
    }
}

class Multipliy1 implements Runnable {
    void multiplyn() {
        for (int i = 1; i < 50; i++) {
            System.out.println(i + " * 1 = " + i * 1);
        }
    }

    @Override
    public void run() { 
        multiplyn();
    }
}
class Multipliy2 implements Runnable {
    void multiplyn() {
        for (int i = 1; i < 50; i++) {
            System.out.println(i + " * 2 = " + i * 2);
        }
    }

    @Override
    public void run() { 
        multiplyn();
    }
}
class Multipliy3 implements Runnable {
    void multiplyn() {
        for (int i = 1; i < 50; i++) {
            System.out.println(i + " * 3 = " + i * 3);
        }
    }

    @Override
    public void run() { 
        multiplyn();
    }
}
class Multipliy4 implements Runnable {
    void multiplyn() {
        for (int i = 1; i < 50; i++) {
            System.out.println(i + " * 4 = " + i * 4);
        }
    }

    @Override
    public void run() { 
        multiplyn();
    }
}
class Multipliy5 implements Runnable {
    void multiplyn() {
        for (int i = 1; i < 50; i++) {
            System.out.println(i + " * 5 = " + i * 5);
        }
    }

    @Override
    public void run() { 
        multiplyn();
    }
}

class addition implements Runnable {
    void add(int n) {
        int sum = (n * (n + 1)) / 2;
        System.out.println("Sum of " + n + " Natural Numbers: " + sum);
    }

    @Override
    public void run() { 
        add(100);
    }
}