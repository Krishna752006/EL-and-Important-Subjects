//java program to demonstrate Treeset using string objects

import java.util.*;
public class Set5
{
	public static void main(String args[])
	{
		TreeSet<String> ss= new TreeSet<>();
		ss.add("C");
		ss.add("D");
		ss.add("B");
		ss.add("A");		
		System.out.println(ss);
		
	}
}
	
