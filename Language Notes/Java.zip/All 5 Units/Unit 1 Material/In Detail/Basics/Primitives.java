class Primitives
{
	public static void main(String args[])
	{
		float f=3.5F;
		long l=2147483648L;
		System.out.println(f);
		System.out.println(Integer.MAX_VALUE);
		System.out.println(l);
		
		System.out.println(56); 
		System.out.println(0b11); 
		System.out.println(017); 
		System.out.println(0x1F); 

		short s=(short)32767;
		System.out.println(s);

		int i;
		//System.out.println(i);
		
	}
}