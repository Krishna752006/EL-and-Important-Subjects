class Test
{
	public static void main(String[] args)
	{
		System.out.println("Hello World");
		int a=10,b=20,s=a+b;
		System.out.println("Sum of a and b is:"+s);
		System.out.format("Sum of %d and %d is %d",a,b,s);
	}
}