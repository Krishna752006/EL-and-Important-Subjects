class Person
{
	int v=5;
	void makeCall()
	{
		System.out.println("grand parent class makecall called");
	}	
}
