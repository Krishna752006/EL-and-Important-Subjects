class Subscriber1 
{
	int sno;
	void makeCall()
	{
		System.out.println("Base class makecall called");
	}
	void receiveCall()
	{
		System.out.println("Base class receivecall called");
	}
}
