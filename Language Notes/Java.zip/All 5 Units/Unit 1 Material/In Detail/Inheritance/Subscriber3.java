class Subscriber3 
{
	
	Subscriber3(int x)
	{
		System.out.println("Base class parameterized constructor gets called");
	}
	void makeCall()
	{
		System.out.println("Base class makecall called");
	}
	void receiveCall()
	{
		System.out.println("Base class receivecall called");
	}
}
