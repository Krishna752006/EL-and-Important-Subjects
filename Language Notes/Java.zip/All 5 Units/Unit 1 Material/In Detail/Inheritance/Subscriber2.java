class Subscriber2
{

	Subscriber2()
	{
		System.out.println("Base class constructor gets called");
	}
	
	void makeCall()
	{
		System.out.println("Base class makecall called");
	}
	void receiveCall()
	{
		System.out.println("Base class receivecall called");
	}
}
