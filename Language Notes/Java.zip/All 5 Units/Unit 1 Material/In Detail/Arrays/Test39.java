/* Display array elements in reverse order*/
class Test39

{
    public static void main(String args[])
     {
	int[] a={10,20,30,40};

	      for(int i=a.length-1;i>=0;i--)
	    {
		System.out.println(a[i]);

   	     }
       }
}

