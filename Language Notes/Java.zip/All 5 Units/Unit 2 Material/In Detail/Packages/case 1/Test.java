package telecom;

public class Test 
{
	public static void main(String args[])
	{
		Employee e=new Employee(28,"Neha");
	}
}
