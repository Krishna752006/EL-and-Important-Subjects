package organization1;
import organization.*;
public class Test2
{  
	public static void main(String args[]) 
	{  
    	Employee e=new Employee();
	e.display();
	Manager m=new Manager();
	m.disp();
    }  
}