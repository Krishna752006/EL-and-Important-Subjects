package organization;  
public class Manager
{  
    public  void disp() 
	{  
        System.out.println("Welcome to Microsoft");  
    }  
}