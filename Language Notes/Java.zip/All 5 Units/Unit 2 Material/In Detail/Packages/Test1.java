import telecom.Employee;

class Test1 
{
	public static void main(String args[])
	{
		Employee e=new Employee(28,"Neha");
		//System.out.println(e.name);
	}
}
