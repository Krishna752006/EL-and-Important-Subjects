//Protected

import Google.Employee3;
public class Modifier3 extends Employee3
{  
 public static void main(String args[])
 {  
   Modifier3 e1=new Modifier3();  
   System.out.println(e1.id);  
   e1.display(); 
 }  
}