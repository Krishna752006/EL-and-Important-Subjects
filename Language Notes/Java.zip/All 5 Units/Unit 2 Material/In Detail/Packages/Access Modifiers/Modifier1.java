//Access modifier: private
public class Modifier1
{  
 public static void main(String args[])
 {  
   Employee1 e1=new Employee1();  
   //System.out.println(e1.id);//Private data member  
   e1.display();  
 }  
}  