//Default
package Google;
class Employee2
{
	int id=101;
	Employee2()
	{
		System.out.println("Default constructor called");
	} 
	void display()
	{
		System.out.println("ID:"+id);
	}  
}
