//Private
class Employee1
{
	private int id=101;
	Employee1()
	{
		System.out.println("Default constructor called");
	} 
	void display()
	{
		System.out.println("ID:"+id);
	}  
}
 
