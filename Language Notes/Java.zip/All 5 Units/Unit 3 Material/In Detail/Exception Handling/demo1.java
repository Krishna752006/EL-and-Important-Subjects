//To demonstrate that we get run time exception
class demo1
{
    public static void main(String args[])
    {
            System.out.println("Hello");
            System.out.println("KMIT");
            System.out.println(10/0);
            System.out.println("Have a nice day");
            System.out.println("Bye");
    }
}
