function startTimerCallback(seconds, callback) {
  setTimeout(callback, seconds*1000);
}

function startTimerPromise(seconds) {
  return new Promise((resolve) => {
    setTimeout(resolve, seconds * 1000);
  });
}

async function startTimerAsync(seconds) {
  await startTimerPromise(seconds);
}

// === UI Logic ===
const startBtn = document.getElementById('start-btn');
const timerInput = document.getElementById('timer-input');
const statusDiv = document.getElementById('timer-status');

startBtn.addEventListener('click', () => {
  const seconds = Number(timerInput.value) || 3;

  // Disable button and show loading
  startBtn.disabled = true;
  statusDiv.textContent = "Loading...";
  statusDiv.className = "loading";

  // ======== Uncomment ONE block below at a time for each style ========

  // ------- Callback Style -------
  startTimerCallback(seconds, () => {
    statusDiv.textContent = "Time's up!";
    statusDiv.className = "done";
    startBtn.disabled = false;
  });


  // ------- Promise Style -------
  startTimerPromise(seconds)
    .then(() => {
      statusDiv.textContent = "Time's up!";
      statusDiv.className = "done";
    })
    .finally(() => {
      startBtn.disabled = false;
    });

  // ------- Async/Await Style -------
  async function runTimer() {
    await startTimerAsync(seconds);
    statusDiv.textContent = "Time's up!";
    statusDiv.className = "done";
    startBtn.disabled = false;
  }
  runTimer();
});