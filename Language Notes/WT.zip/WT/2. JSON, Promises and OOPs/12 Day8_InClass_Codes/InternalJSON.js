/* EmployeeInfo
Write a JS program to fetch the Employee Information from a JSON and 
for the given Employee Id, find his/her first name and last name in Camel Case 
and print the salary.

Input Format :
--------------
Line 1: A number, employee id

Output Format :
---------------
Line 1: A String, employee name in Camel Case
Line 2: A String, employee salary

Note : If employee found with given id print "Invalid Employee ID! Kindly check."

Sample Input 1:
---------------
Enter the Employee Id: 123

Sample Output 1:
---------------
Name: Alex Valley                                                                                                       
Salary: $1234 

Sample Input 2:
---------------
Enter the Employee Id: 130

Sample Output 2:
---------------                                                                                          
Invalid Employee ID! Kindly check. 

*/

const employeeInfo = [
  {
    "eid": "123",
    "fname": "alex",
    "lname": "valley",
    "salary": "$1234",
    "Role": "SDE",
    "doj": "2021-04-22",
    "dob": "1986-06-10"
  },
  {
    "eid": "124",
    "fname": "shrey",
    "lname": "agathwar",
    "salary": "$2345",
    "Role": "HR",
    "doj": "2019-05-15",
    "dob": "1975-09-13"
  },
  {
    "eid": "125",
    "fname": "viral",
    "lname": "shant",
    "salary": "$3456",
    "Role": "JDE",
    "doj": "2018-03-05",
    "dob": "1984-05-23"
  },
  {
    "eid": "126",
    "fname": "candy",
    "lname": "fest",
    "salary": "$4567",
    "Role": "Manager",
    "doj": "2020-09-23",
    "dob": "1985-08-31"
  }
]
    
let readline=require('readline').createInterface({input:process.stdin,output:process.stdout});
let eid;
readline.question('Enter the Employee Id: ',function(line){
        eid=line;
        solution(eid,employeeInfo);
        readline.close();
    });

function solution(id,employeeInfo) {
    //Write your code here
    let flag=0;
    for(let emp of employeeInfo){
        if(emp.eid===id){
            fname = emp.fname.charAt(0).toUpperCase()+emp.fname.slice(1);
            lname = emp.lname.charAt(0).toUpperCase()+emp.lname.slice(1);
           console.log(`Name: ${fname} ${lname}`);
           console.log(`Salary: ${emp.salary}`)
           flag=1;
        }
    }
    if(flag===0)
        console.log('Invalid Employee ID! Kindly check.');
}
/*
Test cases:
case=1
input=123
output=Enter the Employee Id:                                                                                               
Name: Alex Valley                                                                                                       
Salary: $1234 
case=2
input=126
output=Enter the Employee Id:
Name: Candy Fest
Salary: $4567
case=3
input=130
output=Enter the Employee Id:                                                                                              
Invalid Employee ID! Kindly check.
case=4
input=125
output=Enter the Employee Id:
Name: Viral Shant
Salary: $3456
*/