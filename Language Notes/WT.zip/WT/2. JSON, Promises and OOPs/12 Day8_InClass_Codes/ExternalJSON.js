/* AverageWorkingDays
Write a Java Script Program to fetch JSON data that has the list of number of days 
the employee worked each month of the year,
Calculate the average no of working days and display the months where he exceeded his average .

NOTE : Please refer employeeInfo.json

Sample Input 1:
---------------
Enter the Employee Id: 1

Sample Output 1:
----------------
2: 20                                                                                                                   
3: 21                                                                                                                   
9: 19                                                                                                                   
10: 22                                                                                                                  
11: 22                                                                                                                  
12: 20        

Sample Input 2:
---------------
Enter the Employee Id: 5

Sample Output 2:
----------------                                                                                              
Invalid Employee Id! Kindly check.


*/

let obj = require('./employeeInfo.json');

let readline=require('readline').createInterface({input:process.stdin,output:process.stdout});
let eid;
readline.question('Enter the Employee Id: ',function(line){
    eid=line;
    solution(eid,obj.edata);
    readline.close();
});

function solution(id,obj)
{
    //Write your code here
    let ans=0;
    let sum=0,avg=0;
    let flag = false;
    for(let i of obj){
        if(i.eid==id){
            flag = true;
            for(let j=0;j<12;j++){	
                sum=sum+parseInt(i.workingdays[j]);
            }   
            avg=sum/12;

            for(let j=0;j<12;j++){
                if(parseFloat(i.workingdays[j])>avg){
                    console.log((j+1)+': '+i.workingdays[j]);
                }
            }
           
        }
    }
    if(flag===false)
    console.log('Invalid Employee Id! Kindly check.');
}
/*
Test cases:
case=1
input=1
output=Enter the Employee Id:                                                                                                 
2: 20                                                                                                                   
3: 21                                                                                                                   
9: 19                                                                                                                   
10: 22                                                                                                                  
11: 22                                                                                                                  
12: 20        

case=2
input=3
output=Enter the Employee Id:                                                                                               
2: 20                                                                                                                   
3: 21                                                                                                                   
5: 20                                                                                                                   
6: 20                                                                                                                   
7: 20                                                                                                                   
8: 22                                                                                                                   
10: 22                                                                                                                  
11: 22                                                                                                                  
12: 20 

case=3
input=5
output=Enter the Employee Id:                                                                                                
Invalid Employee Id! Kindly check.

*/