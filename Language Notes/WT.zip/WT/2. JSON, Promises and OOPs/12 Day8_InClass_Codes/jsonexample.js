// 1. Simple Values
// {
//     "name": "Santro",
//     "color": "white",
//     "carNumber": "XYZ123",
//     "modelYear": "2020"
// }

// 2. Objects
// {
//     "name": "Kmit",
//     "rating": function callKmit(){
//         alert("Kmit has been rated 5/5 !")
//     }
// }

/* We can convert JSON data to a javascript format and vice versa.

A JSON data 'jsonData' can be converted into javascript data by using the syntax given below.

var jsObject = JSON.parse(jsonData);

A javascript object 'jsObject' can be converted to JSON data by using the syntax given below.

var jsonData = JSON.stringify(jsObject);

*/

// 3. Arrays 
// Arrays can also be scored in the JSON format. 
// Given below is an example of a JSON data array of cars.

// {
//     "cars":[
//         {
//             "name": "Santro",
//             "color": "white",
//             "carNumber": "XYZ123",
//             "modelYear": "2020"
//         },
//         {
//             "name": "Swift",
//             "color": "silver",
//             "carNumber": "XYZ234",
//             "modelYear": "2021"
//         },
//         {
//             "name": "WagonR",
//             "color": "black",
//             "carNumber": "XYZ345",
//             "modelYear": "2022"
//         }
//     ] 
// }

// Why JSON?

// 1. It is a lightweight data-interchange format. 
// This means that we can export JSON data to spreadsheets / XML as well as import data from spreadsheets / XML to JSON.
// 2. JSON is faster and its syntax is very easy to understand.
// 3. It is easier to read JSON data as compared to other data formats like XML.
// 4. JSON data format is not only limited to javascript. 
// It is also used in other programming languages like python etc.
// 5. JSON can also store arrays, objects, and strings in it.

