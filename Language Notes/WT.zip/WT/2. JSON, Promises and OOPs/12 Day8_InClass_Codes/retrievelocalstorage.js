// Step 4: Get the JSON string from localStorage
const savedStr = localStorage.getItem("prefs");

// Step 5: Convert the JSON string back to a JS object
const savedPrefs = JSON.parse(savedStr);

// Step 6: Use the stored preferences
console.log(savedPrefs.theme); // "dark"
console.log(savedPrefs.fontSize); // 18
