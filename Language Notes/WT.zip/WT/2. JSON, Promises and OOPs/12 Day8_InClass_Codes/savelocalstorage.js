// Step 1: Create an object with user preferences
const prefs = { theme: "dark", fontSize: 18 };

// Step 2: Convert the object to a JSON string
const prefsStr = JSON.stringify(prefs);

// Step 3: Save it in localStorage
localStorage.setItem("prefs", prefsStr);


// Change the font size and save again
// prefs.fontSize = 24;
// localStorage.setItem("prefs", JSON.stringify(prefs));

// Remove only preferences
// localStorage.removeItem("prefs");

// Clear all localStorage (CAUTION: affects all saved keys!)
// localStorage.clear();
