// const user = {
//   name: "Alice",
//   age: 25,
//   skills: ["JS", "HTML", "CSS"],
// };
// console.log(user)
// console.log(typeof user)

// const jsonEx = '{"name" : "Alice","age": 25,"skills": ["JS", "HTML", "CSS"]}'
// console.log(typeof jsonEx)

// const user = {
//   name: "Alice",
//   age: 25,
//   skills: ["JS", "HTML", "CSS"],
//   salary: undefined,
//   position: null,
//   hired: false,
//   print: function(){
//     return this.name;
//   }
// };
// console.log(user)
// console.log(user.name)
// console.log(user.print())


// const jsonEx = JSON.stringify(user) 
// console.log(typeof jsonEx)
// console.log(jsonEx)

// const data = JSON.parse(jsonEx)
// console.log(typeof data)
// console.log(data)

const obj = { a: 1, b: 2, c: 3 };
// const jsonEx = JSON.stringify(obj,['C']);
// const jsonEx = JSON.stringify(obj,['a','c']);
const jsonEx = JSON.stringify(obj,['a','b']); 
console.log(jsonEx)

// const json = '{"name":"Bob", "date":"2023-07-24T10:00:00.000Z"}';
// const obj = JSON.parse(json,
//     (key,value)=> {
//         if(key==='date')
//             return new Date(value) 
//         else
//             return value
//      })
// console.log(obj)
// const obj = JSON.parse(json, (key, value) =>
//   key === 'date' ? new Date(value) : value
// );
// console.log(obj.dateinstanceof Date); // true

