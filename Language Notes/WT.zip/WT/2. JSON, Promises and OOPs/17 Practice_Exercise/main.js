// ===== Data =====
const products = [
    { id: 1, name: "Apple", brand: "Apple", price: 50, image: "APPLE.jpeg" },
    { id: 2, name: "Banana", brand: "Banana", price: 20, image: "BANANA.jpeg" },
    { id: 3, name: "Mango", brand: "Mango", price: 70, image: "MANGO.jpeg" }
];

let cart = [];

// ===== Module 1: Product Rendering =====
// Render all items in #product-list as .item cards
function renderProducts(productArray) {
    // TODO: Clear #product-list and render all products as .item cards
}

// ===== Module 2: Sorting and Filtering =====
// Add event listeners for #sort-select and #filter-select
document.getElementById('sort-select').addEventListener('change', function () {
    // TODO: Sorting logic
});
document.getElementById('filter-select').addEventListener('change', function () {
    // TODO: Filtering logic
});

// ===== Module 3: Cart Logic =====
// Add product to cart, increment qty, remove, etc.
// Use #cart-body for rendering rows

// ===== Module 4: Total Calculation =====
// Update #total-cost on any cart change

// ===== Initial Render =====
renderProducts(products);
