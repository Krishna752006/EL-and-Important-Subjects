// Scenario 1) Array basics — first steps

// Goal: Extract values positionally.

// const nums = [10, 20, 30];
// const [a, b, c] = nums;
// console.log(a, b, c); // 10 20 30

// Scenario 2) Skipping items
// const [first, , third] = [1, 2, 3];
// console.log(first, third); // 1 3

//SCenario Object basics — pull by key
//const user = { name: "Sam", age: 25 };
// const { name, age } = user;
// console.log(name, age); // Sam 25

// const { age, name } = user;
// console.log(name, age); // Sam 25

//keys should match while destructuring
//order doesn’t matter; keys do.

//Scenario 4) Aliases (renaming)
// const product = { id: "p1", price: 499 };
// const { id: productId, price: cost } = product;
// console.log(productId, cost); // p1 499

//Scenario- 5) Defaults (missing keys)
// const settings = { theme: "dark" };
// const { theme, fontSize = 16 } = settings;
// console.log(theme, fontSize); // dark 16

//Scenario-6 Realistic Patterns
//Swap variables (classic trick)
// let x = 1, y = 2;
// [x, y] = [y, x];
// console.log(x, y); // 2 1

//Scenario-7 Rest operator (collect the rest)
// const [top, ...others] = [98, 95, 90, 88];
// console.log(top, others); // 98 [95, 90, 88]

// const { id, ...props } = { id: 1, name: "A", price: 10 };
// console.log(id, props); // 1 { name: "A", price: 10 }

//Scenario -8) Nested destructuring (safe pick)
// const person = { 
//     name: "Alex", 
//     address: { city: "Pune", zip: "411001"} 
// };
// const { address: { city, zip } } = person;
// console.log(city, zip); // Pune 411001


// Scanario - 9) Safe deep defaults 
// (defend against missing)
// const payload = {};
// const { meta: { client: { os = "unknown" } = {} } = {} } = payload;
// console.log(os); // "unknown"

//Scenario-10 Function parameter destructuring
// function greet({ name = "Guest", role = "User" }) {
//   return `Hello ${name} (${role})`;
// }
// console.log(greet({name: "Priya"  })); // Hello Priya (User)
// console.log(greet({name: "Supriya", role: "HR" }));

// Scenario- 11 Map callback destructuring
const items = [
  { sku: "A1", price: 100, qty: 2 },
  { sku: "B2", price: 50,  qty: 3 }
];
const lines = items.map(({ sku, price, qty }) => 
    ({ sku, total: price * qty })
);
console.table(lines);





