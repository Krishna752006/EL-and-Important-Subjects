// let is_shop_open = true;
// babystep1
// let order = ( time, work ) =>{
//     return new Promise( ( resolve, reject )=>{ } )
// }

// //babystep2
// // Our promise has 2 parts:

// // Resolved [ ice cream delivered ]
// // Rejected [ customer didn't get ice cream ]
// let order = ( time, work ) => {
//     return new Promise( ( resolve, reject )=>{
//       if( is_shop_open ){
//         resolve( )
//       }
//       else{
//         reject( console.log("Our shop is closed") )
//       }
//     })
//   }
// // Step 1: Select Fruit
// order(2000, () => console.log(`${stocks.Fruits[0]} was selected`))

let is_shop_open = false;

let stocks = { 
  Fruits: ["strawberry", "grapes", "banana", "apple"],
  liquid: ["water", "ice"],
  holder: ["cone", "cup", "stick"],
  toppings: ["chocolate", "peanuts"],
};

//Function to handle time-based tasks using Promise
let order = (time, work) => {
  return new Promise((resolve, reject) => {
    if (is_shop_open) {
      setTimeout(() => {
        //work();  // Perform the task
        resolve();  // Resolve after task is done
      }, time);
    } else {
      reject(console.log("Our shop is closed"));
    }
  });
};

// // Step 1: Select Fruit
order(2000, () => console.log(`${stocks.Fruits[0]} was selected`))
// Step 2: Production Start
.then(() => {
    return order(0, () => console.log("production has started"));
})
// Step 3: Chop Fruit
.then(() => {
    return order(2000, () => console.log("Fruit has been chopped"));
})
// Step 4: Add liquid
.then(() => {
    return order(1000, () => console.log(`${stocks.liquid[0]} and ${stocks.liquid[1]} added`));
})
// Step 5: Start machine
.then(() => {
    return order(1000, () => console.log("start the machine"));
})
// Step 6: Place ice cream in holder
.then(() => {
    return order(2000, () => console.log(`ice cream placed on ${stocks.holder[1]}`));
})
// Step 7: Add toppings
.then(() => {
    return order(3000, () => console.log(`${stocks.toppings[0]} as toppings`));
})
// Step 8: Serve Ice Cream
.then(() => {
    return order(2000, () => console.log("Serve Ice Cream"));
})

// Catch block for errors (if shop is closed)
.catch(() => {
    console.log("Customer left because shop is closed.");
})
  
.finally(()=>{
    console.log("end of day")
});
