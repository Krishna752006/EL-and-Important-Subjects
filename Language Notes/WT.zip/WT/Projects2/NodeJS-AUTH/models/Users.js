const { default: mongoose } = require("mongoose");

const mongoose=require(mongoose);
 const UserSchema=new mongoose.Scehma