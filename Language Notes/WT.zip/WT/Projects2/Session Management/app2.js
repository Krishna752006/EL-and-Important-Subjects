const express = require('express');
const session = require('express-session');
const MongoStore = require('connect-mongo');
const mongoose = require('mongoose');

const app = express();

// Connect to MongoDB
mongoose.connect("mongodb://127.0.0.1:27017/sessionDB")
  .then(() => console.log("MongoDB Connected"))
  .catch(err => console.log(err));

// Middleware to read form data
app.use(express.urlencoded({ extended: true }));

// Session Middleware (Store in MongoDB)
app.use(
  session({
    secret: "mySecretKey123", // security key
    resave: false,
    saveUninitialized: false,
    store: MongoStore.create({
      mongoUrl: "mongodb://127.0.0.1:27017/sessionDB",
      collectionName: "sessions"   // collection where sessions will be stored
    }),
    cookie: { maxAge: 1000 * 60 * 1 } // 5 minutes
  })
);

// Simple login
app.get("/", (req, res) => {
  res.send(`
    <form method="POST" action="/login">
      <input name="username" placeholder="Enter your name" required/>
      <button type="submit">Login</button>
    </form>
  `);
});

app.post("/login", (req, res) => {
  req.session.username = req.body.username;
  res.send(`
    <h3>Login Successful</h3>
    <a href="/dashboard">Go to Dashboard</a>
  `);
});

// Dashboard
app.get("/dashboard", (req, res) => {
  if (req.session.username) {
    res.send(`
      <h2>Welcome ${req.session.username}</h2>
      <a href="/logout">Logout</a>
    `);
  } else {
    res.send("Please Login first <a href='/'>Login</a>");
  }
});

// Logout
app.get("/logout", (req, res) => {
  req.session.destroy(() => {
    res.send("Logged out <a href='/'>Login again</a>");
  });
});

app.listen(3001, () => console.log("Server running on http://localhost:3001"));
