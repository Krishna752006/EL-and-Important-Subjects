Session Management in Node.js & Express.js
--------------------------------------------
1. What is a Session?
------------------------
A session is a way to store user data on the server temporarily while they browse your website.

Example:
When you log in to a website, it remembers you on every page — this is done using sessions.

Why Do We Need Sessions?
----------------------------
✔ To keep users logged in
✔ To store temporary data (cart items, preferences, etc.)
✔ To track user activities
✔ To secure pages (dashboard, profile, etc.)

2. How Sessions Work?
-----------------------
Step-by-step:

User logs in → server creates a session.
Server saves a session ID.
Server sends a session cookie to the browser.
Browser sends this cookie on every request.
Server reads the cookie and identifies the user.

3. Installing Session Package
-------------------------------
Express uses:
express-session
Install:
npm install express-session



Where is session stored?
---------------------------

✔ Inside the server’s RAM (memory)
❌ You cannot see it in any file
❌ It disappears when you restart the server
❌ It is not saved in MongoDB

MemoryStore is only for testing, not production.

You cannot see the session value stored in any database.


Explanation:
------------
app.use(session({
    secret: 'mySecretKey123',
    resave: false,
    saveUninitialized: true,
    cookie: { maxAge: 60000 } // 1 minute
}));

secret → Used to sign the session ID (security)

resave → Do not save session if not modified

saveUninitialized → Save new sessions

cookie.maxAge → Session expiry time (in ms)

Session Storage Options:
--------------------------
Default: ✔ Memory Store (not recommended for production)

For Production use these:
-------------------------
Redis
MongoDB (connect-mongo)
MySQL store
PostgreSQL store

Summary Table
----------------
| Feature           | Description                         |
| ----------------- | ----------------------------------- |
| Session           | Stores temporary user data          |
| Cookie            | Sent to browser to remember session |
| express-session   | Main session library                |
| req.session       | Object to store/read data           |
| session.destroy() | Logout                              |



Store sessions in MongoDB using connect-mongo with Express.js.
-------------------------------------------------------------------------
1. Install Dependencies:
--------------------------
npm install express express-session connect-mongo mongoose

Why these?
---------------
express → server
express-session → sessions
connect-mongo → saves sessions in MongoDB
mongoose → connects to MongoDB (optional but recommended)