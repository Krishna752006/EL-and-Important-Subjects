const express = require("express");
const session = require("express-session");

const app = express();

app.use(express.urlencoded({ extended: true }));  // to read form data

// SESSION MIDDLEWARE
app.use(
  session({
    secret: "mySuperSecret123", // protect session id
    resave: false,
    saveUninitialized: true,
    cookie: { maxAge: 60000 } // 1 minute
  })
);

// HOME PAGE (FORM)
app.get("/", (req, res) => {
  res.send(`
        <h2>Login Page</h2>
        <form method="POST" action="/login">
            <input type="text" name="username" placeholder="Enter your name" required />
            <button type="submit">Login</button>
        </form>
    `);
});

// LOGIN ROUTE (store username in session)
app.post("/login", (req, res) => {
  req.session.username = req.body.username;
  res.send(`
        <h3>Login Successful!</h3>
        <a href="/dashboard">Go to Dashboard</a>
    `);
});

// DASHBOARD (protected page)
app.get("/dashboard", (req, res) => {
  if (req.session.username) {
    res.send(`
            <h2>Welcome ${req.session.username}</h2>
            <p>This is your dashboard.</p>
            <a href="/logout">Logout</a>
        `);
  } else {
    res.send(`
            <h3>You are not logged in!</h3>
            <a href="/">Login Again</a>
        `);
  }
});

// LOGOUT (destroy session)
app.get("/logout", (req, res) => {
  req.session.destroy(() => {
    res.send(`
            <h3>You have been logged out.</h3>
            <a href="/">Login Again</a>
        `);
  });
});

// START SERVER
app.listen(3000, () => console.log("Server running on http://localhost:3000"));
