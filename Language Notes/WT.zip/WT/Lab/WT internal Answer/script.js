document.addEventListener('DOMContentLoaded', () => {
    // --- DOM Elements ---
    const productGrid = document.getElementById('product-grid');
    const cartItemsContainer = document.getElementById('cart-items');
    const totalAmountElement = document.getElementById('total-amount');
    const cartCountElement = document.querySelector('.cart-count');
    const clearCartBtn = document.getElementById('clear-cart-btn');
    const sortSelect = document.getElementById('sort-by');
    const filterButtons = document.querySelectorAll('.filter-btn');

    // --- State Management ---
    let allProducts = [];
    let displayedProducts = [];
    let cart = JSON.parse(localStorage.getItem('cart')) || [];
    let productMeta = JSON.parse(localStorage.getItem('productMeta')) || {};
    // Reset likes and stars on each refresh
    localStorage.removeItem('productMeta');
    productMeta = {};
    const lastAddTimestamps = new Map();

    // --- Helpers ---
    function toNumberSafe(value, fallback = 0) {
        const n = Number(value);
        return Number.isFinite(n) ? n : fallback;
    }

    function sanitizeCartData(existingCart) {
        if (!Array.isArray(existingCart)) return [];
        return existingCart.map(item => {
            const safePrice = toNumberSafe(item.price, 0);
            const safeQty = Math.max(1, toNumberSafe(item.quantity, 1));
            return { ...item, price: safePrice, quantity: safeQty };
        });
    }

    function mergeCartDuplicates(items) {
        const map = new Map();
        items.forEach(item => {
            const key = item.id;
            if (!map.has(key)) {
                map.set(key, { ...item });
            } else {
                const existing = map.get(key);
                existing.quantity = Math.max(1, toNumberSafe(existing.quantity, 1)) + Math.max(1, toNumberSafe(item.quantity, 1));
            }
        });
        return Array.from(map.values());
    }

    cart = mergeCartDuplicates(sanitizeCartData(cart));

    // --- Fetch Products ---
    async function fetchProducts() {
        try {
            const response = await fetch('products.json');
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            allProducts = await response.json();
            // Merge persisted meta (likes/ratings)
            allProducts = allProducts.map(p => ({ ...p }));
            // Reconcile cart with current product catalog to avoid phantom items
            cart = mergeCartDuplicates(sanitizeCartData(cart)).filter(item =>
                allProducts.some(p => p.id === item.id)
            );
            displayedProducts = [...allProducts];
            renderProducts(displayedProducts);
            updateCart();
        } catch (error) {
            console.error("Could not fetch products:", error);
            productGrid.innerHTML = '<p>Error loading products. Please try again later.</p>';
        }
    }

    // --- Render Products ---
    function renderProducts(productsToRender) {
        productGrid.innerHTML = '';
        if (productsToRender.length === 0) {
            productGrid.innerHTML = '<p>No products found.</p>';
            return;
        }

        productsToRender.forEach(product => {
            const card = document.createElement('div');
            card.className = 'product-card';
            card.dataset.id = product.id;

            card.innerHTML = `
                <div class="flip-card" data-id="${product.id}">
                    <div class="flip-card-inner">
                        <div class="flip-card-front">
                            <div class="product-image-container">
                                <img src="${product.image}" alt="${product.name}" loading="lazy" onerror="this.onerror=null;this.src='https://images.unsplash.com/photo-1515543237350-b3eea1ec8082?q=80&w=300&auto=format&fit=crop';">
                            </div>
                        </div>
                        <div class="flip-card-back">
                            <div class="product-back-content">
                                <h4>${product.name}</h4>
                                <p>${product.description}</p>
                            </div>
                        </div>
                    </div>
                </div>
                <h3>${product.name}</h3>
                <p class="product-type">${product.type}</p>
                <p class="product-price">₹${product.price}</p>
                <div class="product-rating" data-id="${product.id}">
                    ${[1,2,3,4,5].map(n => `\n                        <button class=\"star-btn\" data-star=\"${n}\" aria-label=\"Rate ${n} star\">★</button>`).join('')}
                </div>
                <div class="product-actions">
                    <button class="add-to-cart-btn" data-id="${product.id}">Add to Cart</button>
                    <div class="like-container">
                        <button class="like-btn" data-id="${product.id}"><i class="far fa-heart"></i></button>
                        <span class="like-count">${product.likes}</span>
                    </div>
                </div>
            `;
            productGrid.appendChild(card);
        });
    }

    // --- Cart Functions ---
    function addToCart(productId) {
        if (!Number.isFinite(productId)) {
            console.warn('addToCart called with invalid productId:', productId);
            showToast('Invalid item');
            return;
        }

        const product = allProducts.find(p => p.id === productId);
        if (!product) {
            console.warn('Product not found for id:', productId);
            showToast('Item unavailable');
            return;
        }

        cart = mergeCartDuplicates(cart);
        const cartItem = cart.find(item => item.id === productId);
        if (cartItem) {
            cartItem.quantity = Math.max(1, toNumberSafe(cartItem.quantity, 1)) + 1;
        } else {
            cart.push({ ...product, price: toNumberSafe(product.price, 0), quantity: 1 });
        }
        showToast('Item Added');
        updateCart();
    }

    function removeFromCart(productId) {
        const before = cart.length;
        cart = cart.filter(item => item.id !== productId);
        if (cart.length !== before) {
            updateCart();
            showToast('Item removed', 'info');
        }
    }

    function updateCart() {
        cartItemsContainer.innerHTML = '';
        let total = 0;
        let totalItems = 0;

        cart = mergeCartDuplicates(sanitizeCartData(cart));

        cart.forEach(item => {
            // Skip any item not in catalog as an extra safety net
            if (!allProducts.some(p => p.id === item.id)) return;
            const unitPrice = toNumberSafe(item.price, 0);
            const qty = Math.max(1, toNumberSafe(item.quantity, 1));
            const itemTotal = unitPrice * qty;
            total += itemTotal;
            totalItems += qty;

            const row = document.createElement('tr');
            row.innerHTML = `
                <td><img src="${item.image}" alt="${item.name}"> ${item.name}</td>
                <td>
                    <div class="qty-controls" data-id="${item.id}">
                        <button class="qty-btn qty-decrease" data-id="${item.id}" aria-label="Decrease quantity">−</button>
                        <span class="qty-value">${qty}</span>
                        <button class="qty-btn qty-increase" data-id="${item.id}" aria-label="Increase quantity">+</button>
                    </div>
                </td>
                <td>₹${unitPrice}</td>
                <td>₹${itemTotal}</td>
                <td><button class="remove-btn" data-id="${item.id}">Remove</button></td>
            `;
            cartItemsContainer.appendChild(row);
        });

        totalAmountElement.textContent = toNumberSafe(total, 0).toFixed(2);
        cartCountElement.textContent = totalItems;
        localStorage.setItem('cart', JSON.stringify(mergeCartDuplicates(cart)));
    }

    // --- Clear cart ---
    if (clearCartBtn) {
        clearCartBtn.addEventListener('click', () => {
            cart = [];
            localStorage.setItem('cart', JSON.stringify(cart));
            updateCart();
            showToast('Cart cleared');
        });
    }

    // --- Sorting and Filtering ---
    function applySortAndFilter() {
        let filtered = [...allProducts];

        // Filter
        const activeFilter = document.querySelector('.filter-btn.active').dataset.type;
        if (activeFilter !== 'all') {
            filtered = filtered.filter(p => p.type === activeFilter);
        }

        // Sort
        const sortValue = sortSelect.value;
        switch (sortValue) {
            case 'name-az':
                filtered.sort((a, b) => a.name.localeCompare(b.name));
                break;
            case 'price-lh':
                filtered.sort((a, b) => a.price - b.price);
                break;
            case 'price-hl':
                filtered.sort((a, b) => b.price - a.price);
                break;
        }

        displayedProducts = filtered;
        renderProducts(displayedProducts);
    }

    // --- Event Listeners ---
    productGrid.addEventListener('click', e => {
        const target = e.target;
        if (target.closest('.add-to-cart-btn')) {
            const btn = target.closest('.add-to-cart-btn');
            const productId = parseInt(btn.dataset.id);
            const now = Date.now();
            const last = lastAddTimestamps.get(productId) || 0;
            if (now - last < 400) {
                return; // prevent rapid double add
            }
            lastAddTimestamps.set(productId, now);
            btn.disabled = true;
            addToCart(productId);
            setTimeout(() => { btn.disabled = false; }, 300);
        }
        if (target.closest('.like-btn')) {
            const likeBtn = target.closest('.like-btn');
            const container = likeBtn.parentElement;
            const likeCountSpan = container.querySelector('.like-count');
            const id = parseInt(likeBtn.dataset.id);
            const current = parseInt(likeCountSpan.textContent) || 0;
            const newCount = current + 1;
            likeCountSpan.textContent = newCount;
            likeBtn.innerHTML = '<i class="fas fa-heart"></i>';
            likeBtn.classList.add('liked');
            // persist
            productMeta[id] = productMeta[id] || {};
            productMeta[id].likes = newCount;
            localStorage.setItem('productMeta', JSON.stringify(productMeta));
        }
        if (target.classList && target.classList.contains('star-btn')) {
            const starBtn = target;
            const id = parseInt(starBtn.closest('.product-rating').dataset.id);
            const rating = parseInt(starBtn.dataset.star);
            const wrapper = starBtn.closest('.product-rating');
            wrapper.querySelectorAll('.star-btn').forEach((btn) => {
                const n = parseInt(btn.dataset.star);
                if (n <= rating) btn.classList.add('active'); else btn.classList.remove('active');
            });
            // persist
            productMeta[id] = productMeta[id] || {};
            productMeta[id].rating = rating;
            localStorage.setItem('productMeta', JSON.stringify(productMeta));
        }
        // Flip now handled by CSS :hover
    });

    cartItemsContainer.addEventListener('click', e => {
        const target = e.target;
        if (target.classList.contains('remove-btn')) {
            const productId = parseInt(target.dataset.id);
            removeFromCart(productId);
            return;
        }
        if (target.classList.contains('qty-increase')) {
            const productId = parseInt(target.dataset.id);
            const item = cart.find(i => i.id === productId);
            if (item) {
                item.quantity = Math.max(1, (Number(item.quantity) || 1)) + 1;
                updateCart();
            }
            return;
        }
        if (target.classList.contains('qty-decrease')) {
            const productId = parseInt(target.dataset.id);
            const item = cart.find(i => i.id === productId);
            if (item) {
                const nextQty = Math.max(1, (Number(item.quantity) || 1) - 1);
                item.quantity = nextQty;
                updateCart();
            }
            return;
        }
    });

    sortSelect.addEventListener('change', applySortAndFilter);

    filterButtons.forEach(button => {
        button.addEventListener('click', () => {
            filterButtons.forEach(btn => btn.classList.remove('active'));
            button.classList.add('active');
            applySortAndFilter();
        });
    });

    // --- Utility Functions ---
    let toastTimer;
    function showToast(message, type = 'success') {
        const toast = document.getElementById('toast');
        if (!toast) return;
        toast.textContent = message;
        toast.classList.remove('success', 'error', 'info');
        if (type) toast.classList.add(type);
        toast.classList.add('show');
        clearTimeout(toastTimer);
        toastTimer = setTimeout(() => {
            toast.classList.remove('show');
        }, 3000);
    }

    // --- Initial Load ---
    fetchProducts();
});