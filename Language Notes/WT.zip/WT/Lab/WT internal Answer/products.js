document.addEventListener('DOMContentLoaded', async () => {
    const grid = document.getElementById('category-product-grid');
    const title = document.getElementById('category-title');
    // Reset likes/ratings on category refresh
    localStorage.removeItem('productMeta');
    const productMeta = {};

    // Get product type from URL query parameter
    const params = new URLSearchParams(window.location.search);
    const productType = params.get('type');

    if (!productType) {
        grid.innerHTML = '<p>No category specified.</p>';
        return;
    }

    // Update the page title
    title.textContent = `${productType === 'all' ? 'All' : productType} Fruits`;

    try {
        const response = await fetch('products.json');
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        let allProducts = await response.json();
        
        const filteredProducts = productType === 'all' 
            ? allProducts 
            : allProducts.filter(p => p.type === productType);

        renderCategoryProducts(filteredProducts);
    } catch (error) {
        console.error("Error fetching or filtering products:", error);
        grid.innerHTML = '<p>Could not load products for this category.</p>';
    }

    function renderCategoryProducts(products) {
        grid.innerHTML = '';
        if (products.length === 0) {
            grid.innerHTML = '<p>No products found in this category.</p>';
            return;
        }

        products.forEach(product => {
            const card = document.createElement('div');
            card.className = 'product-card';
            card.innerHTML = `
                <div class="flip-card" data-id="${product.id}">
                    <div class="flip-card-inner">
                        <div class="flip-card-front">
                            <div class="product-image-container">
                                <img src="${product.image}" alt="${product.name}" loading="lazy" onerror="this.onerror=null;this.src='https://images.unsplash.com/photo-1515543237350-b3eea1ec8082?q=80&w=300&auto=format&fit=crop';">
                            </div>
                        </div>
                        <div class="flip-card-back">
                            <div class="product-back-content">
                                <h4>${product.name}</h4>
                                <p>${product.description}</p>
                            </div>
                        </div>
                    </div>
                </div>
                <h3>${product.name}</h3>
                <p class="product-type">${product.type}</p>
                <p class="product-price">₹${product.price}</p>
                <div class="product-rating" data-id="${product.id}">
                    ${[1,2,3,4,5].map(n => `\n                        <button class=\"star-btn\" data-star=\"${n}\" aria-label=\"Rate ${n} star\">★</button>`).join('')}
                </div>
                 <div class="product-actions">
                    <button class="add-to-cart-btn-dummy">Add to Cart</button>
                    <div class="like-container">
                        <button class="like-btn" data-id="${product.id}"><i class="far fa-heart"></i></button>
                        <span class="like-count">${product.likes}</span>
                    </div>
                </div>
            `;
            grid.appendChild(card);
        });
        
        document.querySelectorAll('.add-to-cart-btn-dummy').forEach(btn => {
            btn.addEventListener('click', () => alert('Please add items from the Home page!'));
        });

        // Likes and rating interactions
        grid.addEventListener('click', (e) => {
            const target = e.target;
            if (target.closest && target.closest('.like-btn')) {
                const likeBtn = target.closest('.like-btn');
                const container = likeBtn.parentElement;
                const likeCountSpan = container.querySelector('.like-count');
                const id = parseInt(likeBtn.dataset.id);
                const current = parseInt(likeCountSpan.textContent) || 0;
                const newCount = current + 1;
                likeCountSpan.textContent = newCount;
                likeBtn.innerHTML = '<i class="fas fa-heart"></i>';
                likeBtn.classList.add('liked');
                productMeta[id] = productMeta[id] || {};
                productMeta[id].likes = newCount;
                localStorage.setItem('productMeta', JSON.stringify(productMeta));
            }
            if (target.classList && target.classList.contains('star-btn')) {
                const starBtn = target;
                const id = parseInt(starBtn.closest('.product-rating').dataset.id);
                const rating = parseInt(starBtn.dataset.star);
                const wrapper = starBtn.closest('.product-rating');
                wrapper.querySelectorAll('.star-btn').forEach((btn) => {
                    const n = parseInt(btn.dataset.star);
                    if (n <= rating) btn.classList.add('active'); else btn.classList.remove('active');
                });
                productMeta[id] = productMeta[id] || {};
                productMeta[id].rating = rating;
                localStorage.setItem('productMeta', JSON.stringify(productMeta));
            }
            // Flip now handled by CSS :hover
        });
    }
});