let fruits = [], currentFruits = [], cart = [];

fetch("fruits.json")
  .then(r => r.json())
  .then(d => {
    fruits = currentFruits = d;
    renderFruits(d);
    setupEventListeners();
  });


// event listeners for filter and sort dropdowns
function setupEventListeners() {
  document.getElementById("type-filter").onchange = handleTypeFilter;
  document.getElementById("sort-select").onchange = () => {
    applySort();
    renderFruits(currentFruits);
  };
}

// filtering fruits
function handleTypeFilter(e) {
  currentFruits = e.target.value === "all" ? fruits : fruits.filter(f => f.type === e.target.value);

  applySort();
  renderFruits(currentFruits);
}

// sort the current fruits array
function applySort() {
  const v = document.getElementById("sort-select").value;
  currentFruits = [...currentFruits].sort((a, b) =>
    v === "name" ? a.name.localeCompare(b.name) :
      v === "price-low" ? a.price - b.price :
        v === "price-high" ? b.price - a.price : 0
  );
}

// render fruits
function renderFruits(list) {
  const c = document.getElementById("fruits-grid");
  c.innerHTML = "";
  list.forEach(f => c.appendChild(createFruitCard(f)));
}

// create a single fruit card element
function createFruitCard(f) {
  const col = document.createElement("div"); // Create a column div
  col.className = "col-md-4 mb-4";           // Set Bootstrap classes


  // Rating stars calculation
  const fullStars = Math.floor(f.rating);         // Number of full stars
  const emptyStars = 5 - fullStars;               // Remaining empty stars
  const stars = "★".repeat(fullStars) + "☆".repeat(emptyStars);

  // Set inner HTML of the card (flip card front/back, name, type, price, buttons)
  col.innerHTML = `
  <div class="card h-100">
    <div class="flip-container"><div class="flip-inner">
      <div class="flip-front"><img src="${f.image}" class="card-img-top" alt="${f.name}"></div>
        <div class="flip-back">
          <div class="card-body d-flex align-items-center justify-content-center">
            <p>${f.description}</p>
          </div>
        </div>
      </div>
    </div>

    <div class="card-body">
      <h5>${f.name}</h5>
      <p><small>Type: ${f.type}</small></p>
      <div>${stars}</div>
      <p class="fw-bold">$${f.price.toFixed(2)}</p>
      <button class="btn btn-outline-danger btn-sm like-btn">❤️ <span class="like-count">0</span></button>
      <button class="btn btn-primary btn-sm add-to-cart-btn"> Add to Cart</button>
    </div>

  </div>`;

  const likeBtn = col.querySelector(".like-btn");
  const cartBtn = col.querySelector(".add-to-cart-btn");

  likeBtn.onclick = () => likeBtn.querySelector(".like-count").textContent++;
  cartBtn.onclick = () => (addToCart(f), showToast(`${f.name} added to cart!`));
  return col;
}

// add a fruit to the cart
function addToCart(f) {
  const i = cart.find(x => x.id === f.id); // Check if already in cart
  i ? i.qty++ : cart.push({ ...f, qty: 1 }); // Increment qty or add new item
  updateCartDisplay();                     // Refresh cart display
}

// remove a fruit from the cart 
function removeFromCart(id) {
  cart = cart.filter(x => x.id !== id);
  updateCartDisplay();
}

// update the cart UI and total amount
const updateCartDisplay = () => {
  const c = document.getElementById("cart-items"), t = document.getElementById("total-amount");
  if (!c || !t) return;
  let total = 0;
  c.innerHTML = cart.map(i => (total += i.price * i.qty, `
    <div class="row cart-item mb-3 p-2 border rounded">
      <div class="col-md-2">
        <img src="${i.image}" class="img-thumbnail" style="width:60px;height:60px;object-fit:cover">
      </div>
      <div class="col-md-4 d-flex align-items-center">${i.name}</div>
      <div class="col-md-3 d-flex align-items-center">$${i.price.toFixed(2)} x ${i.qty} = $${(i.price * i.qty).toFixed(2)}</div>
      <div class="col-md-3 d-flex align-items-center">
        <button class="btn btn-danger btn-sm" onclick="removeFromCart(${i.id})">Remove</button>
      </div>
    </div>`
  )).join("");
  t.textContent = `Total Amount: $${total.toFixed(2)}`;
};

const showToast = msg => {
  const t = document.body.appendChild(document.createElement("div"));
  t.className = "position-fixed top-0 end-0 m-3 bg-success text-white p-3 rounded shadow";
  t.style = "z-index:1055;max-width:300px;opacity:0;transition:.5s";
  t.textContent = msg;
  setTimeout(() => t.style.opacity = 1, 10);
  setTimeout(() => (t.style.opacity = 0, setTimeout(() => t.remove(), 500)), 2000);
};
