//Import libraries
import express from "express";
import mongoose from "mongoose";

// Create Express app
const app = express();

// Middleware to parse JSON
app.use(express.json());

// MongoDB connection URI
const uri = "mongodb://127.0.0.1:27017/studentDB";

// Connect to MongoDB
mongoose.connect(uri)
.then(() => console.log("MongoDB Connected Successfully!"))
.catch(err => console.error("MongoDB Connection Failed:", err));

//Create a schema and model
const studentSchema = new mongoose.Schema({
  name: String,
  age: Number,
  course: String
});

const Student = mongoose.model("Student", studentSchema);

// Function to add 3 students automatically
const addStudents = async () => {
    const students = [
    { name: "Anusha", age: 21, course: "B.Tech" },
    { name: "Bilahari", age: 20, course: "B.Sc" },
    { name: "Pratyusha", age: 22, course: "B.Com" }
  ];
  try {
    await Student.insertMany(students); // insert 3 students at once
    console.log("3 Students added successfully!");
  } catch (err) {
    console.error("Error adding students:", err);
  }
};

// Route to get all students
app.get("/students", async (req, res) => {
  try {
    const students = await Student.find();
    res.status(200).json(students);
  } catch (err) {
    res.status(500).send("Error: " + err);
  }
});

// Start server
const PORT = 3000;
app.listen(PORT, async () => {
  console.log(`Server running at http://localhost:${PORT}`);
  await addStudents();
});
