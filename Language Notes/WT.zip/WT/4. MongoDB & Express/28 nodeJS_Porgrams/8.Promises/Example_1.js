function delaFn(time)
{
    return new Promise((resolve)=>setTimeout(resolve,time))
}

console.log("welocme to promises concept");

delaFn(5000).then(()=> console.log("after 5 seconds promise is resolved "))

console.log("end");