/*In Node.js, the File System (fs) module allows you to 
interact with files and directories on your computer 
for — reading, writing, updating, deleting, and more.

It is a built-in core module, so you don’t need to install anything. 
Just use:
const fs = require("fs");

Types of File System methods:
-------------------------------
The fs module provides two ways to work with files:

1.Asynchronous (non-blocking) → recommended for performance.
Uses callbacks or promises.

2.Synchronous (blocking) → simple but blocks the event loop until 
                           operation finishes.
*/

//Example-1: create  a directory(we use ‘path.join’ method)

const fs=require('fs');
const path=require('path');

const datafolder=path.join(__dirname,"data");

if(!fs.existsSync(datafolder))
{
    fs.mkdirSync(datafolder);
    console.log("data folder created");
}

//create new file inside current folder(Directory)
const filepath=path.join(datafolder,"example.txt");

//synchronous way of creating file with some text 

fs.writeFileSync(filepath,"Keshav Memorial Institute of Technology");
console.log("file created successfully with some text");

//read data from file using synchronous way

const readfromfile=fs.readFileSync(filepath,"utf8");
console.log("File content:",readfromfile);
