//append data into new line of  existing file

const { clear } = require('console');

const fs=require('fs');
const path=require('path');

const datafolder=path.join(__dirname,"data");

if(!fs.existsSync(datafolder))
{
    fs.mkdirSync(datafolder);
    console.log("data folder created");
}

const filepath=path.join(datafolder,"example.txt");
//synchronous way of creating file with some text 

fs.appendFileSync(filepath,"\n autonomous institution ");

//fs.appendFileSync("example.txt","\n autonomous institution ");
console.log("new file content added");