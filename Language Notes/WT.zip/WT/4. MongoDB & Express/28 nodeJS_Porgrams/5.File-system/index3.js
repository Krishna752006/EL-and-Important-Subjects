//async way of creating the file

const fs=require('fs');

const path=require('path');

//join method used to safely combine (join) multiple path segments into a single, properly formatted file path.

const datafolder=path.join(__dirname,"data");

if(!fs.existsSync(datafolder))
{
    fs.mkdirSync(datafolder);
    console.log("data folder created");
}

const asyncfilepath=path.join(datafolder,"async-example.txt");

fs.writeFile(asyncfilepath,"hello, KMIT ,narayanguda",(err)=>{
    if(err)
       throw err;
    console.log("async file is created successfully");
    
})

/*In Node.js, when you work with the File System (fs) module,
-->the term utf-8 refers to the character encoding used when reading or writing text files.
-->UTF-8 (Unicode Transformation Format – 8-bit) is a standard text encoding that 
represents characters from almost all languages.

-->It’s the most common encoding on the web and ensures that your file’s text
(like Hindi, Telugu, emojis, or special characters) is correctly stored and displayed.

Why use utf-8 in fs?
-----------------------
By default, fs reads and writes binary buffers (raw bytes).
If you want to handle text (strings), you must tell Node.js which encoding to use — and 'utf-8' is the most common one.
*/

//read text from existing file using async way

fs.readFile(asyncfilepath,"utf8",(err,data)=>{
    if(err)
        throw err;
    console.log("async file content:",data)
});


//adding data into  another line (async file) 

fs.appendFile(asyncfilepath,`\n Departments:CSE,CSM,IT and CSD`,(err)=>{
    if(err) throw err;
    console.log("new line added to async file");
})

//reading updated data from file
fs.readFile(asyncfilepath,"utf8",(err,updateddata)=>{
    if(err)
        throw err;
    console.log("updated file content:",updateddata)
});

