/*create package.json command is “npm init”  this is 1st way

create package.json command is “npm init -y”  this is 2nd way- here ‘y’ indicates ‘yes’

-->install predefined packages(multiple dependencies):
 ->example package name: ‘lodash’ 
 ->command : npm install lodash
 ->Here node_modules directory (which contains predefined files) added bydefault 
  and package-lock.json files is created 

-->Like we can do ‘npm uninstall’-package names uninstall and 
-->also we can update package using ‘npm update’ and 

how to add start script in package.json file
-------------------------------------------- 
open package.josn file and search "start" key and write file name like below format
Ex: “start”: ”node index.js”

-->also if we run different scripts that we can see in package.json file 
and  we need to do ‘npm run’ 

-->command:npm run  press enter will get below informtion  
Lifecycle scripts included in 3.node-package-manager@1.0.0:
  test
    echo "Error: no test specified" && exit 1
  start
    node index.js

-->use npm start command, index.js file executing directly
command: npm start   press enter will get below informtion

> 3.node-package-manager@1.0.0 start
> node index.js

[ 'John', 'Alexa', 'Terry', 'Maria' ]

*/
//example program-1: capatalize first character in each word

const lodash=require("lodash");
const names=["john","alexa","terry","maria"];
const result=lodash.map(names,lodash.capitalize);
console.log(result);
