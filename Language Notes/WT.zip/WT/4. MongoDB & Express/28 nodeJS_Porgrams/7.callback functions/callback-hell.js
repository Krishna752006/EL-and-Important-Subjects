//callback-hell example on file system

const fs=require("fs");

fs.readFile("input.txt","utf-8",(err,data)=> {
    if(err)
    {
        console.error("Error reading File",err);
        return;
    }

const modifyFiledata= data.toUpperCase();

fs.writeFile("output.txt",modifyFiledata,(err)=>{
    if(err)
    {
        console.error("Error writing file",err);
        return;
    }
    console.log("data written to the new file");

    fs.readFile("output.txt","utf-8",(err,data)=>{
        if(err)
        {
            console.error("Error reading File",err);
            return;     
        }
    })
  })
});