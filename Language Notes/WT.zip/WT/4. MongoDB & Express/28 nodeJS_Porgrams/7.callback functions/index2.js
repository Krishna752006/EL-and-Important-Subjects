// callback Example on FileSystem

const fs=require('fs');

function person(name,callbackFn)
{
    console.log(`Hello ${name}`)
    callbackFn()
}

function address()
{
console.log("Hyderabad")
}

person("KMIT",address);

fs.readFile("input.txt","utf-8",(err,data)=>{
if(err)
{
    console.error("Erro reading File  ", err)
    return;
}
console.log(data)
});

/*output:
Hello KMIT
Hyderabad
keshv memorial institute of technology
*/
