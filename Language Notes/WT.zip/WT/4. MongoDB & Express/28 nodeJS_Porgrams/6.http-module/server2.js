//Example-1 continue- For getting responses we use some predefined methods 

const http=require('http')


const server=http.createServer((req,res)=> {

    /*req is a huge object of type IncomingMessage.
If you log it directly, your console will print something like this (simplified):
*/
console.log(req,"req")

//  console.log("Method:", req.method);
//   console.log("URL:", req.url);
//   console.log("Headers:", req.headers);

res.writeHead(200,{"Content-Type":"text/plain"});

/*res.end() is used to: Finish (end) the response process,
Optionally send the last piece of data to the client.
When you call res.end(), Node.js:
Sends all headers and body to the client,
Closes the response stream.
*/
res.end("hello node.js from http modules")


//Server with Different HTTP Methods
if (req.method === "GET") {
    res.end("This is a GET request");
  } else if (req.method === "POST") {
    res.end("This is a POST request");
  } else {
    res.end("Other HTTP method");
  }
});

const port=3002;
server.listen(port,()=>{
    console.log(`server is now listeing to port ${port}`)
})



/*🧩 What is 200

👉 200 is an HTTP status code.
It tells the client (browser, Postman, etc.) whether the request was successful or not.

Common HTTP Status Codes:
Code	Meaning	                    Description
----    -------                     -----------
200	    OK ✅	                 Request was successful, and the server is returning data.
201	    Created	                   A new resource was created (used for POST).
400	    Bad Request ❌             The client sent invalid data.
401	    Unauthorized 🔒	           Login/authentication required.
404	    Not Found 🚫	           The requested page or resource does not exist.
500	    Internal Server Error 💥   Something went wrong on the server.

So in our code:
res.writeHead(200, ...)
means:
“Everything went fine. I’m sending back a successful response.”

🧩 What is { "content-type": "text/plain" }
-------------------------------------------------

This is called the HTTP header — specifically, the Content-Type header.
It tells the browser what kind of data is being sent in the response body.

Content-Type	            Meaning
---------------------       -----------------
"text/plain"	            Simple plain text
"text/html"	                HTML document
"application/json"	        JSON data
"image/png"	                PNG image
"text/css"	                CSS stylesheet
"application/javascript"	JavaScript code

🔹 Why Content-Type is Mandatory
----------------------------------
It’s not always technically required, but it’s strongly recommended (almost mandatory) because:

🧠 Browsers need to know how to interpret the data.

If you send HTML but don’t specify "text/html", the browser might show 
it as plain text instead of rendering the webpage.

🧩 APIs and apps need to parse data correctly.

For example, if a client expects JSON, 
it reads based on the Content-Type: application/json header.

⚙️ Security and consistency.


*/
