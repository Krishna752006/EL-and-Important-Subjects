//Example-2: creating routes  we require url variable

const http=require('http')
const server=http.createServer((req,res)=>{

    const URL=req.url;

    if(URL=="/")
    {
        res.writeHead(200,{"Content-Type":"text/plain"})
        res.end("home page")

    }
    else if (URL=="/projects")
    {
        res.writeHead(200,{"Content-Type":"text/html"})
       // res.end("will get porjetcs directory data")
        res.end("<h1>Hello Node.js</h1><p>This is an HTML response</p>");

    }
    else if (URL=="/jsondata")
    {
        const data = { name: "Kmit", city: "Hyderabad" };
        res.writeHead(200, { "content-type": "application/json" });
        res.end(JSON.stringify(data));

    }
    else 
        res.writeHead(404,{"Content-Type":"text/plain"})
    res.end("this page is can not be found")
})

const port=3000;
server.listen(port,()=>{
    console.log(`server is listening to port number ${port} `)
})