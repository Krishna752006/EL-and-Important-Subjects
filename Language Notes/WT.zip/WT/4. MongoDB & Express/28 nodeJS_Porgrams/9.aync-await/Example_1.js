function delayFn(time)
{
    return new Promise((resolve)=>setTimeout(resolve,time));
}

async function delayedGreet(name) 
{
  await delayFn(5000);
  console.log(name)  
}
delayedGreet("John");