//Import libraries
import express from "express";
import mongoose from "mongoose";

// Create Express app
const app = express();

// Middleware to parse JSON
app.use(express.json());

// MongoDB connection URI
const uri = "mongodb://127.0.0.1:27017/studentDBS";

// Connect to MongoDB
mongoose.connect(uri)
    .then(() => console.log("MongoDB Connected Successfully!"))
    .catch(err => console.error("MongoDB Connection Failed:", err));

//Create a schema and model
const studentSchema = new mongoose.Schema({
    roll: {type: Number, unique : true},
    name: String,
    age: Number,
    course: String
});

const Student = mongoose.model("Student", studentSchema);

// Route to READ all students
app.get("/students", async (req, res) => {
    try {
        const students = await Student.find();
        res.status(200).json(students);
    } catch (err) {
        res.status(500).send("Error: " + err);
    }
});
// Route to CREATE student
app.post("/students", async (req, res) => {
    try {
        const newStudent = new Student(req.body);
        await newStudent.save();
        res.status(201).send("Student added successfully!");
    } catch (err) {
        res.status(500).send("Error: " + err);
    }
});

// READ a single student by studentId
app.get("/students/:studentId", async (req, res) => {
  try {
    const student = await Student.findOne({ roll: req.params.studentId });
    if (!student) return res.status(404).json({ message: "Student not found!" });
    res.status(200).json(student);
  } catch (err) {
    res.status(500).json({ error: "Error: " + err });
  }
});

// Route to UPDATE student by studentId
app.put("/students/:studentId", async (req, res) => {
  try {
    const updatedStudent = await Student.findOneAndUpdate(
      { roll: req.params.studentId },
      req.body,
      { new: true }
    );
    if (!updatedStudent) return res.status(404).json({ message: "Student not found!" });
    res.json({
      message: "Student updated successfully!",
      student: updatedStudent
    });
  } catch (err) {
    res.status(500).json({ error: "Error: " + err });
  }
});

// Route to DELETE student by studentId
app.delete("/students/:studentId", async (req, res) => {
  try {
    const deletedStudent = await Student.findOneAndDelete({ roll: req.params.studentId });
    if (!deletedStudent) return res.status(404).json({ message: "Student not found!" });
    res.json({ message: " Student deleted successfully!" });
  } catch (err) {
    res.status(500).json({ error: "Error: " + err });
  }
});

// Start server
const PORT = 3000;
app.listen(PORT, async () => {
    console.log(`Server running at http://localhost:${PORT}`);
});
