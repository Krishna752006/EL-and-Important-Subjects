import express from "express";
import mongoose from "mongoose";
import path from "path";
import { fileURLToPath } from "url";
import dotenv from  "dotenv"

dotenv.config();

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: true })); // for form data

// For __dirname in ES6 modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Serve static HTML
app.use(express.static(path.join(__dirname, "public")));

const uri = process.env.MONGO_URI;

mongoose.connect(uri)
    .then(() => console.log("MongoDB Connected Successfully!"))
    .catch(err => console.error("MongoDB Connection Failed:", err));

// Schema & Model
const studentSchema = new mongoose.Schema({
    roll: { type: Number, unique: true },
    name: String,
    age: Number,
    course: String
});

const Student = mongoose.model("Student", studentSchema);

// POST route to add student from form
app.post("/students", async (req, res) => {
    try {
        const newStudent = new Student(req.body);
        await newStudent.save();
        res.send(`<h2> Student added successfully!</h2>
              <a href="/">Add another student</a>`);
    } catch (err) {
        res.status(500).send("Error: " + err);
    }
});

// GET route to see all students
app.get("/students", async (req, res) => {
    try {
        const students = await Student.find();
        res.json(students);
    } catch (err) {
        res.status(500).send("Error: " + err);
    }
});

// Start server
const PORT = process.env.PORT;
app.listen(PORT, () => console.log(`Server running at http://localhost:${PORT}`));
