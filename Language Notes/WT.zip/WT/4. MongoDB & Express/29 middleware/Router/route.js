const express = require('express')
const router = express.Router()

//middlewares
const auth = function (req, res, next){
    console.log('I am in auth middlware')
    //creating dummy user
    req.user = {userId:1, role:"employee"}
    if(req.user){
        //if a valid user, then proceed to next middleware
        next()
    }else{
        //not a valid user
        res.json({
            success:false,
            message: "Not a valid user"
        })
    }
}

const isEmployee = function (req, res, next){
    console.log('I am in employee middleware')

    if(req.user.role==='employee'){
        next()
    }else{
        res.json({
            success:false,
            message: "Access denied, this route is only for employee"
        })
    }
}

const isAdmin = function (req, res, next){
    console.log('I am in admin middlware')

    if(req.user.role==='admin'){
        next()
    }else{
        res.json({
            success:false,
            message: "Access denied, this route is only for admin"
        })
    }
}

//route
router.get('/employee', auth, isEmployee, (req, res)=>{
    console.log('I am in employee route')
    res.send("Hello employee ")
})

router.get('/admin',auth, isAdmin, (req, res)=>{
    console.log('I am in admin route')
    res.send("Hello admin ")
})

module.exports = router