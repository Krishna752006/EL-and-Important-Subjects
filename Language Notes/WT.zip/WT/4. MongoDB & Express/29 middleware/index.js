const express = require('express')
const app = express()
const port =3000

const routes = require('./Router/route')

app.use('/api',routes)

/*
//inbuilt middleware
app.use(express.json())

//middleware - logging, auth, validation

//creation of log middleware
const logM = function (req, res, next){
    console.log("I am in logging.")
    next()
}

//creation of auth middleware
const authM = function (req, res, next){
    console.log("I am in auth.")
    //res.send("I am stopping the request-response-cycle")
    next()
}

//creation of validation middleware
const validM = function (req, res, next){
    console.log("I am in validation.")
    next()
}

//loading a log middleware
app.use(logM)
//loading a middleware
app.use(authM)
//loading a middleware
app.use(validM)
*/



//route
app.get('/',(req, res)=>{
    console.log('in home route')
    console.log(req.body)
    res.send("Hello world")
})

app.listen(port,()=>{
    console.log(`App is running on port ${port}...`)
})