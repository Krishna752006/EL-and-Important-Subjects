// import packages -- express
// server is ready
//server is listening at a port - 4000

let express = require('express');
let app = express();

//app.use(express.json());
app.use((req,res,next)=>{
    console.log("First block,request originated....");
    next();
})

app.use('/public',express.static(path.join(__dirname,"public")));

app.get("/users/:usname",async(req,res)=>{
    let resp=await fetch("http://localhost:4000/public/users.json")
    let data=await resp.json();
    console.log(data);
    res.send(data);
})
app.get('/',(req,res)=>{
    console.log('Reached route second block');
    res.send(" REached root route");
});

app.post('/',(req,res)=>{
    res.send(" REached root post method route");
});

app.post('/postcheck',(req,res)=>{
    res.send(" REached postcheck route");
});

app.delete('/deletecheck',(req,res)=>{
    res.send(" REached deletecheck route");
});

app.put('/checkput',(req,res)=>{
    res.send(" REached checkput route");
});

app.post('/register',(req,res)=>{
    console.log(req.body);
    //use this info, store the data 
    res.send(" REached root route");
});

app.listen(4000,() => { console.log(" Backend server running at port 4000")});


